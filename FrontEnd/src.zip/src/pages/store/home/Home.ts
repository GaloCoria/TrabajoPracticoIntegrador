import { PRODUCTS, getCategories } from "../../../data/data";
import type { Product } from "../../../types/product";
import type { ICategory } from "../../../types/categoria";

const contenedorProductos = document.getElementById('contenedor-productos') as HTMLElement;
const inputBusqueda = document.getElementById('input-busqueda') as HTMLInputElement;
const listaCategorias = document.getElementById('lista-categorias') as HTMLUListElement;


function mostrarCategorias(): void {
    const categorias: ICategory[] = getCategories();

    if (!listaCategorias) return;

    listaCategorias.innerHTML = '';

    const itemTodas = document.createElement('li');
    itemTodas.textContent = 'Todas';
    itemTodas.style.cursor = 'pointer';
    itemTodas.addEventListener('click', () => renderizarProductos(PRODUCTS));
    listaCategorias.appendChild(itemTodas);

    categorias.forEach(cat => {
        const li = document.createElement('li');
        li.textContent = cat.nombre;
        li.style.cursor = 'pointer';

        li.addEventListener('click', () => {
            
            const filtrados = PRODUCTS.filter(p => 
                p.categorias.some(c => c.id === cat.id)
            );
            renderizarProductos(filtrados);
        });

        listaCategorias.appendChild(li);
    });
}


function renderizarProductos(productosAMostrar: Product[]): void {
    if (!contenedorProductos) return;

    contenedorProductos.innerHTML = '';

    
    if (productosAMostrar.length === 0) {
        contenedorProductos.innerHTML = '<p class="error-msg">No se encontraron productos para esta búsqueda.</p>';
        return;
    }

    productosAMostrar.forEach(producto => {
        const card = document.createElement('div');
        card.className = 'product-card';

        
        const puedeComprar = producto.disponible && producto.stock > 0;

        card.innerHTML = `
            <img src="${producto.imagen}" alt="${producto.nombre}">
            <div class="card-content">
                <small>${producto.categorias[0]?.nombre || 'General'}</small>
                <h3>${producto.nombre}</h3>
                <p>${producto.descripcion}</p>
                <p class="price">$${producto.precio.toLocaleString('es-AR')}</p>
                <button class="${puedeComprar ? 'btn-add' : 'btn-disabled'}" ${puedeComprar ? '' : 'disabled'}>
                    ${puedeComprar ? 'Agregar al Carrito' : 'Sin Stock'}
                </button>
            </div>
        `;

        const boton = card.querySelector('button');
        boton?.addEventListener('click', () => {
            agregarAlCarrito(producto);
        });

        contenedorProductos.appendChild(card);
    });
}


function configurarBuscador(): void {
    if (!inputBusqueda) return;

    inputBusqueda.addEventListener('input', () => {
        const termino = inputBusqueda.value.toLowerCase().trim();

        const filtrados = PRODUCTS.filter(p => 
            p.nombre.toLowerCase().includes(termino) ||
            p.descripcion.toLowerCase().includes(termino) ||
            p.categorias.some(c => c.nombre.toLowerCase().includes(termino))
        );

        renderizarProductos(filtrados);
    });
}


function agregarAlCarrito(producto: Product): void {
    const carritoJson = localStorage.getItem('carrito');
    const carrito = carritoJson ? JSON.parse(carritoJson) : [];

    
    const index = carrito.findIndex((item: any) => item.id === producto.id);

    if (index !== -1) {
        carrito[index].cantidad += 1;
    } else {
        
        carrito.push({ ...producto, cantidad: 1 });
    }

    localStorage.setItem('carrito', JSON.stringify(carrito));
    alert(`${producto.nombre} fue agregado al carrito.`);
}


function init(): void {
    mostrarCategorias();
    renderizarProductos(PRODUCTS);
    configurarBuscador();
}


init();