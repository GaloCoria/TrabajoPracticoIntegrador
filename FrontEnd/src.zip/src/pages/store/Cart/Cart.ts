import type { CartItem } from "../../../types/product";


const contenedorCarrito = document.getElementById('lista-carrito') as HTMLTableSectionElement;
const textoTotal = document.getElementById('total-precio') as HTMLSpanElement;
const btnFinalizar = document.getElementById('btn-finalizar') as HTMLButtonElement;
const btnVaciar = document.getElementById('btn-vaciar') as HTMLButtonElement;


function mostrarCarritoVacio(): void {
    if (!contenedorCarrito) return; 
    contenedorCarrito.innerHTML = `
        <tr>
            <td colspan="6" style="text-align:center; padding: 30px; color: #666;">
                <h3>Tu carrito está vacío</h3>
                <p>¡Volvé a la tienda para elegir algo rico!</p>
            </td>
        </tr>
    `;
    if (textoTotal) textoTotal.textContent = '$0,00';
    if (btnFinalizar) btnFinalizar.disabled = true;
    if (btnVaciar) btnVaciar.disabled = true;
}   


function renderizarCarrito(): void {
    const datos = localStorage.getItem('carrito');
    const carrito: CartItem[] = datos ? JSON.parse(datos) : [];    
    
    if (carrito.length === 0) {
        mostrarCarritoVacio();
        return;
    }

    if (!contenedorCarrito) return;
    contenedorCarrito.innerHTML = '';
    let total = 0;

    carrito.forEach(item => {
        const subtotal = item.precio * item.cantidad;
        total += subtotal;  

        const row = document.createElement('tr');
        row.innerHTML = `
            <td><img src="${item.imagen}" alt="${item.nombre}" style="width: 50px; border-radius: 5px;"></td>
            <td><strong>${item.nombre}</strong></td>
            <td>$${item.precio.toLocaleString('es-AR')}</td>
            <td>
                <div class="controles-cantidad">
                    <button class="btn-cantidad" data-id="${item.id}" data-action="decrease">-</button>
                    <span class="cantidad-numero">${item.cantidad}</span>
                    <button class="btn-cantidad" data-id="${item.id}" data-action="increase">+</button>
                </div>
            </td>
            <td>$${subtotal.toLocaleString('es-AR')}</td>
            <td><button class="btn-eliminar" data-id="${item.id}">🗑️</button></td>
        `;
        contenedorCarrito.appendChild(row);
    });

    
    if (textoTotal) textoTotal.textContent = `$${total.toLocaleString('es-AR')}`;
    if (btnFinalizar) btnFinalizar.disabled = false;
    if (btnVaciar) btnVaciar.disabled = false;          


    configurarEventosItems();
}


function configurarEventosItems(): void {
    const botonesCantidad = document.querySelectorAll('.btn-cantidad');
    const botonesEliminar = document.querySelectorAll('.btn-eliminar');

    botonesCantidad.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const target = e.currentTarget as HTMLButtonElement;
            const id = parseInt(target.getAttribute('data-id') || '0');
            const action = target.getAttribute('data-action');
            modificarCantidad(id, action === 'increase' ? 1 : -1);
        });
    });

    botonesEliminar.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const target = e.currentTarget as HTMLButtonElement;
            const id = parseInt(target.getAttribute('data-id') || '0');
            eliminarDelCarrito(id);
        });
    });
}


function modificarCantidad(id: number, delta: number): void {
    const carrito: CartItem[] = JSON.parse(localStorage.getItem('carrito') || '[]');
    const index = carrito.findIndex(item => item.id === id);
    
    if (index !== -1) {
        carrito[index].cantidad += delta;
        
        
        if (carrito[index].cantidad < 1) {
            if (confirm('¿Querés eliminar este producto del carrito?')) {
                eliminarDelCarrito(id);
                return;
            } else {
                carrito[index].cantidad = 1;
            }
        }
        
        localStorage.setItem('carrito', JSON.stringify(carrito));
        renderizarCarrito();
    }
}


function eliminarDelCarrito(id: number): void {
    let carrito: CartItem[] = JSON.parse(localStorage.getItem('carrito') || '[]');
    carrito = carrito.filter(item => item.id !== id);
    localStorage.setItem('carrito', JSON.stringify(carrito));
    renderizarCarrito();
}


function configurarBotonesGlobales(): void {
    btnVaciar?.addEventListener('click', () => {
        if (confirm('¿Estás seguro de que querés vaciar todo el carrito?')) {
            localStorage.removeItem('carrito');
            renderizarCarrito();
        }
    });

    btnFinalizar?.addEventListener('click', () => {
        alert('¡Pedido enviado! Gracias por confiar en Food Store.');
        localStorage.removeItem('carrito');
        renderizarCarrito();
    });
}


function init(): void {
    configurarBotonesGlobales();
    renderizarCarrito();
}

init();